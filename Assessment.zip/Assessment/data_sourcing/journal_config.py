JOURNAL_DOI = { 
    "The Journal of Finance": "10.1111/jofi.", 
    "Journal of Operations Management": "10.1002/joom.",
    "Journal of Accounting Research": "10.1111/1475-679X."
}

JOURNAL_ID = { 
    "The Journal of Finance": "15406261", 
    "Journal of Operations Management": "18731317",
    "Journal of Accounting Research": "1475679x"
}

GEMINI_API_KEY = 'API_KEY'